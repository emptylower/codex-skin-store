# Codex Skin Install Prompt v1

theme_id: theme-1
version: 1
name: Neon Road
payload_digest: a83d609c36a6638e57ec5e26696bdc77636bd89f3b0bbae00d45598f35ee7b7e

## Selected platforms
- platform=macos target=original-macos-v1 runtime_commit=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
- platform=windows target=forge-windows-v1 runtime_commit=bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb

## Compatibility targets
- original-macos-v1
- forge-windows-v1

## File hashes
- adapters/macos/theme.json: 0ad2180bfed3f8e3eef150e8a3bb7dc26e61a2de19e0fd8e24f7c5907e252fd0
- adapters/windows/theme.json: 31c17caf0c3a5510d3ceb456d2b11b322345f51cc54b792c2ecd5bfe157645c5
- background.png: 4de5af4273daffd12fe2ca1401052d5444584e4fa52058a50f663c3533844b4a
- INSTALL.md: 4e5ed8f646e4cef1eb7be05b8cb87dada61a81906a6a059db577a232c99b5ef8
- manifest.json: 444ab86689eb1c322ab9dc3233d1945505173a2c798e069d057f4c900126faf1
- preview.jpg: 3ae62182143e6e1275229d4ef8ab15b9f52cff23561b7551f17988ba726e754f

## Ordered instructions
1. Detect the host OS and map it to a selected platform above.
2. Require the official Codex app plus the pinned target runtime for that platform.
3. Stop immediately if any prerequisite is missing.
4. Back up existing theme state before making changes.
5. Verify every listed file hash before copy.
6. Copy only the detected adapter and assets for the selected platform.
7. Run the supported Dream Skin install command for that runtime only.
8. Verify installation succeeded; report exact failures without inventing fixes.

## Prohibitions
Do not modify app.asar, WindowsApps, application signatures, API keys, Base URLs, or model providers.
