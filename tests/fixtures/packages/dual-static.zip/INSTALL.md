# Install Neon Road

Theme ID: `theme-1`  
Version: `1`  
Payload digest: `03d21d90c74eff7ab89b72c3b7faa815a27f10e8628eeb875ae2c92a05de35d5`

## Supported platforms
- macos
- windows

## Compatibility targets
- `original-macos-v1`
- `forge-windows-v1`

## Platform matrix

### macOS

- Compatibility target: `original-macos-v1`
- Runtime pin: `aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa`
- Adapter: `adapters/macos/theme.json`
- Background asset: package root image referenced by the adapter
- Preview: `preview.jpg`

Steps:
1. Install official Codex and the matching Dream Skin runtime.
2. Confirm prerequisites, then back up your current skin state.
3. Verify package file hashes against the list below.
4. Copy only this platform's adapter and assets.
5. Run the supported install command and confirm the theme loads.

### Windows

- Compatibility target: `forge-windows-v1`
- Runtime pin: `bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb`
- Adapter: `adapters/windows/theme.json`
- Background asset: package root image referenced by the adapter
- Preview: `preview.jpg`

Steps:
1. Install official Codex and the matching Dream Skin runtime.
2. Confirm prerequisites, then back up your current skin state.
3. Verify package file hashes against the list below.
4. Copy only this platform's adapter and assets.
5. Run the supported install command and confirm the theme loads.


## File hashes

| Path | SHA-256 |
| --- | --- |
| `adapters/macos/theme.json` | `0ad2180bfed3f8e3eef150e8a3bb7dc26e61a2de19e0fd8e24f7c5907e252fd0` |
| `adapters/windows/theme.json` | `31c17caf0c3a5510d3ceb456d2b11b322345f51cc54b792c2ecd5bfe157645c5` |
| `background.png` | `4de5af4273daffd12fe2ca1401052d5444584e4fa52058a50f663c3533844b4a` |
| `manifest.json` | `444ab86689eb1c322ab9dc3233d1945505173a2c798e069d057f4c900126faf1` |
| `preview.jpg` | `3ae62182143e6e1275229d4ef8ab15b9f52cff23561b7551f17988ba726e754f` |

## Safety

Do not modify app.asar, WindowsApps, application signatures, API keys, Base URLs, or model providers.

Creator description text is intentionally omitted from install instructions.
